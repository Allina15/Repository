import static java.lang.Math.sqrt;

public class Triangle {
    double a;
    double b;
    double c;

    public double area(){
       double area = (a*b)/2;
       return area;
    }
}
